

import math


def find_idcg(topN):
    score = 0.0
    for i in range(topN):
        score += 1 / math.log(i+2)
    return score


def find_ndcg(plist, tlist, topN):
    score=0
    for i in range(topN):
        if tlist[plist[i].astype(int)].astype(int) == 1:
            overlap_num = 1
        else:
            overlap_num=0
        score=score+(math.pow(2,overlap_num)-1)/math.log(i+2)
    return score/find_idcg(topN)



def _order_lists(reference, hypothesis):
    """
    Maps and orders both lists. Ex: ref:[2,5,1,1] and hyp:[2,2,3,1] =>
                                     ref:[5,2,1,1] and hyp:[1,2,5,1]
    """
    pair_ref_list = sorted([x for x in enumerate(reference)], key=lambda x: x[1])
    mapped_hyp_list = [hypothesis[x[0]] for x in pair_ref_list]

    return [x[1] for x in pair_ref_list], mapped_hyp_list


def find_rankdcg(reference, hypothesis):
    reference_list, hypothesis_list = _order_lists(reference, hypothesis)

    ordered_list = reference_list[:] # creating ordered list
    ordered_list.sort(reverse=True)

    high_rank = float(len(set(reference_list))) # max rank
    reverse_rank = 1.0            # min score (reversed rank)
    relative_rank_list = [high_rank]
    reverse_rank_list = [reverse_rank]

    for index, rank in enumerate(ordered_list[:-1]):
        if ordered_list[index+1] != rank:
            high_rank -= 1.0
            reverse_rank += 1.0
        relative_rank_list.append(high_rank)
        reverse_rank_list.append(reverse_rank)

    # map real rank to relative rank
    reference_pair_list = [x for x in enumerate(reference_list)]
    sorted_reference_pairs = sorted(reference_pair_list, key=lambda p: p[1], \
                                    reverse=True)
    rel_rank_reference_list = [0] * len(reference_list)
    for position, rel_rank in enumerate(relative_rank_list):
        rel_rank_reference_list[sorted_reference_pairs[position][0]] = rel_rank

    # computing max/min values (needed for normalization)
    max_score = sum([rank/reverse_rank_list[index] for index, rank \
                     in enumerate(relative_rank_list)])
    min_score = sum([rank/reverse_rank_list[index] for index, rank \
                     in enumerate(reversed(relative_rank_list))])

    # computing and mapping hypothesis to reference
    hypothesis_pair_list = [x for x in enumerate(hypothesis_list)]
    sorted_hypothesis_pairs = sorted(hypothesis_pair_list, \
                                     key=lambda p: p[1], reverse=True)
    eval_score = sum([rel_rank_reference_list[pair[0]] / reverse_rank_list[index] \
                      for index, pair in enumerate(sorted_hypothesis_pairs)])

    return (eval_score - min_score) / (max_score - min_score)
