import datetime
import copy

def cmp_datetime(a, b):
   a_datetime = datetime.datetime.strptime(a, '%Y-%m-%d')
   b_datetime = datetime.datetime.strptime(b, '%Y-%m-%d')

   if a_datetime > b_datetime:
   # if a>b:
        return 1
   elif a_datetime < b_datetime:
   # elif a<b:
        return -1
   else:
        return 0

def get_input_data_train(f):
    #{user,[tid, tid...]}
    urecord={}
    # tdict {tid, {time, plist}}
    tdict = {}
    for line in f:
        l = line.strip().split('\t')
        tdict_elem = {}
        plist = []
        tid = l[0]
        uid = l[-2]
        time = l[-1]
        for i in range(1, len(l)-2):
            plist.append(l[i])
        tdict_elem['time']=time
        tdict_elem['plist']=plist
        tdict[tid]=tdict_elem
        if uid not in urecord.keys():
            tlist=[]
            tlist.append(tid)
            urecord[uid]=tlist
        else:
            tlist=urecord.get(uid)
            tlist.append(tid)
            urecord[uid]=tlist
    # sort each u in urecord
    urecord_sort={}
    for u in urecord:
        sortlist = []
        tlist=urecord.get(u)
        tlistsort={}
        for i in range(len(tlist)):
            tid=tlist[i]
            time=tdict.get(tid).get('time')
            tlistsort[tid]=time
        #tlistsort sort by value
        date_sort = sorted(tlistsort.iteritems(), cmp=cmp_datetime, key=lambda d: d[1], reverse=False)
        #print 'test, sort!', date_sort
        for k in range(len(date_sort)):
            tid=date_sort[k][0]
            sortlist.append(tid)
        urecord_sort[u]=sortlist
   # print 'test, urecord:',len(urecord_sort)
    return urecord_sort,tdict

def write_train_file(urecord_train,urecord_test,tdict_train, tdict_test,ftrain_new):
    max_bn = 0
    min_bn = 10000
    avg_bn = 0
    sum_bn = 0
    max_bp = 0
    min_bp = 10000
    avg_bp = 0
    sum_bp = 0
    u_num = 0
    for i in urecord_train:
        u_num=u_num+1
        tlist_train = urecord_train.get(i)
        tlist_test = urecord_test.get(i)
        ftrain_new.write(i+'\t')
        if len(tlist_train)+1>max_bn:
            max_bn=len(tlist_train)+1
        if len(tlist_train)+1< min_bn:
            min_bn=len(tlist_train)+1
        sum_bn=sum_bn+len(tlist_train)+1
        sum_ubp0=0
        for j in range(len(tlist_train)):
            plist_train=tdict_train.get(tlist_train[j]).get('plist')
            if len(plist_train) < min_bp:
                min_bp = len(plist_train)
            if len(plist_train) > max_bp:
                max_bp = len(plist_train)
            sum_ubp0 = sum_ubp0 + len(plist_train)
            for k in range(len(plist_train)):
                if k == len(plist_train)-1:
                    ftrain_new.write(plist_train[k]+'\t')
                else:
                    ftrain_new.write(plist_train[k] + ' ')
        sum_bp = sum_bp + sum_ubp0 * 1.0 / len(tlist_train)
        for j1 in range(len(tlist_test)):
            plist_test = tdict_test.get(tlist_test[j1]).get('plist')
            for k1 in range(len(plist_test)):
                if k1 == len(plist_test) - 1:
                    ftrain_new.write(plist_test[k1] + '\t')
                else:
                    ftrain_new.write(plist_test[k1] + ' ')
        ftrain_new.write('\n')
    avg_bn = sum_bn * 1.0 /u_num
    avg_bp = sum_bp * 1.0 /u_num
    print 'avg bn, avg bp:', avg_bn, avg_bp
    print 'max bn, maxbp: ', max_bn, max_bp
    print 'min bn, min bp: ', min_bn, min_bp
    ftrain_new.flush()
    ftrain_new.close()


def deal_data_input_category(basketdata,input_data,pcategory_map,input_data_category):
    '''

    :param basketdata: input records
    :param input_data: the input product file for our model
    :param pcategory_map: a dict {pid category}
    :param input_data_category:  the input category file for our model
    :return: umap, pmap, cmap, the map from ture id to index id
    '''
    fin=open(basketdata,'r')
    fpcmap=open(pcategory_map,'r')
    foutp=open(input_data,'w')
    foutc=open(input_data_category,'w')
    pcmap={}
    umap={}
    pmap={}
    cmap={}
    for line in fpcmap:
        pid=line.strip().split('\t')[0]
        cid=line.strip().split('\t')[1]
        pcmap[pid]=cid
    print 'product category map over!',len(pcmap)
    uidx=0
    pidx=1
    cidx=1
    # make analysis the filter impact
    for line in fin:
        ub=line.strip().split('\t')
        umap[ub[0]]=uidx
        uidx=uidx+1
        foutp.write(str(uidx)+'\t')
        foutc.write(str(uidx)+'\t')
        lenub=len(ub)
        for i in range(lenub-1):
            plist=ub[i+1].strip().split()
            lenp=len(plist)
            for j in range(lenp):
                if plist[j] not in pmap.keys():
                    pmap[plist[j]]=pidx
                    if j==lenp-1:
                        foutp.write(str(pidx)+'\t')
                    else:
                        foutp.write(str(pidx)+' ')
                    pidx=pidx+1
                else:
                    if j==lenp-1:
                        foutp.write(str(pmap.get(plist[j]))+'\t')
                    else:
                        foutp.write(str(pmap.get(plist[j])) + ' ')

                if pcmap.get(plist[j]) not in cmap.keys():
                    cmap[pcmap.get(plist[j])]=cidx
                    if j == lenp - 1:
                        foutc.write(str(cidx) + '\t')
                    else:
                        foutc.write(str(cidx) + ' ')
                    cidx = cidx + 1
                else:
                    if j==lenp-1:
                        foutc.write(str(cmap.get(pcmap.get(plist[j])))+'\t')
                    else:
                        foutc.write(str(cmap.get(pcmap.get(plist[j]))) + ' ')
        foutp.write('\n')
        foutc.write('\n')
    foutp.flush()
    foutp.close()
    foutc.flush()
    foutc.close()
   # print 'filter analysis, cb_all, cb_over6, cb_over10, cp_over10, cp_under10', cb_all, cb_over6, cb_over10, cp_over10, cp_under10
    return umap,pmap,cmap

if __name__ == '__main__':
    '''
    ftrain= open('./dataset/tafeng/train.txt', 'r')
    ftest=open('./dataset/tafeng/test.txt', 'r')
    fpc=open('./dataset/tafeng/pcategory_map.txt', 'r')
    urecord_train,tdict_train = get_input_data_train(ftrain)
    urecord_test,tdict_test = get_input_data_train(ftest)
    ftrain_new=open('./dataset/tafeng/user_basket_records.txt', 'w')
    write_train_file(urecord_train,urecord_test,tdict_train, tdict_test,ftrain_new)
    print 'test!, write to file!'
    '''
    """
    max bn: 85 
    max bp: 105
    min bn: 4
    min bp:1
    avg bn: 8.35
    avg bp: 6.61
    """
    # second process
    basketdata = './dataset/tafeng/user_basket_records.txt'
    input_data = './dataset/tafeng/data_product.txt'
    input_data_category = './dataset/tafeng/data_category.txt'
    pcategory_map = './dataset/tafeng/pcategory_map.txt'
    umap, pmap, cmap = deal_data_input_category(basketdata, input_data, pcategory_map, input_data_category)
    print '=============test, user map, product map, category map over!:', len(umap), len(pmap), len(cmap)
