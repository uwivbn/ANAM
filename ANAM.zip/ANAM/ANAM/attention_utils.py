import keras.backend as K
import numpy as np
import random
from keras.layers import merge
from keras.utils import np_utils
from keras.layers.core import *
from keras.layers.recurrent import LSTM
from keras.models import *
from keras.layers import Flatten,Reshape,MaxPooling1D,RepeatVector
from keras.layers import Input
from keras.models import load_model,Sequential
import keras.layers
random.seed(1234)


def get_data(trainpath):
    f=open(trainpath,'r')
    ud={}
    for i in f.readlines():
        temp=i.strip().split('\t')
        ud[int(temp[0])]=[]
        for j in range(len(temp)-1):
            product_list=temp[1+j].split()
            product_list=map(lambda s:int(s),product_list)
            ud[int(temp[0])].append(product_list)
    return ud

def gen_index_indicator_vec(idx, ndims):
    """This function takes a list idx
    idx: np vector of abitrary len, idx.shape=(m,), e.g. idx = [4,7,8,9]
    ndims: the generated indicator vector's dim
    returns: generated binary index indicator vector
    """
    output = np.zeros(ndims)
    for i in range(len(idx)):
        output[idx[i]-1] = 1
    return output


def padding_basket(blist, bnum):
    bpad = []
    for i in range(bnum):
        if i < len(blist)-1:
            bpad.append(blist[i])
        if i== len(blist)-1:
            templist=[]
            if len(blist[i])>1:
                for j in range(len(blist[i])-1):
                    templist.append(blist[i][j])
                bpad.append(templist)
            else:
                bpad.append([])
        if i>= len(blist):
            bpad.append([])
    return bpad


def padding_product(plist, pnum):
    ppad=[]
    for i in range(pnum):
        if i < len(plist):
            ppad.append(plist[i])
        else:
            ppad.append(0)
    return ppad


def gen_index_one_vec(idx):
    BS = idx.shape[0]
    output = np.ones((idx.shape[0], idx.shape[1]))
    for k in range(BS):
        for i in range(idx.shape[1]):
            output[k, i] = i
    return output


def compute_overlap(plist, tlist, topN):
    """
    this function return the overlap num of plist and tlist
    :param plist: the predict list: [3,2,5...]
    :param tlist: the test list[0,1,0....50]
    :param topN: evaluation position
    :return:
    """
    '''
    overlap_num = np.zeros(plist.shape[0],)
    BS = plist.shape[0]
    for i in range(BS):
        for j in range(topN):
            if tlist[i, plist[i, j]] == 1:
                overlap_num[i] = overlap_num[i]+1
    '''
    overlap_num = 0
    for i in range(topN):
        if tlist[plist[i].astype(int)].astype(int) == 1:
            overlap_num = overlap_num + 1

    return overlap_num

def compute_not_zero_new(trainY):
    not_zero_num=0
    for i in range(len(trainY)):
            if trainY[i] == 1:
                not_zero_num= not_zero_num+ 1
    return not_zero_num


def compute_not_zero(trainY):
    """

    :param trainY: the label vector
    :return: the number of product in each basket
    """
    '''
    not_zero_num=np.zeros(trainY.shape[0],)
    BS = trainY.shape[0]
    for i in range(BS):
        for j in range(trainY.shape[1]):
            if trainY[i, j] == 1:
                not_zero_num[i] = not_zero_num[i] + 1
    '''
    not_zero_num=0
    for i in range(trainY.shape[0]):
            if trainY[i] == 1:
                not_zero_num= not_zero_num+ 1
    return not_zero_num


def get_data_analysis(path):
    file=open(path, 'r')
    user_records=[]
    product_records=[]
    count=0
    maxlen=0
    for line in file:
        one_user_record={}
        count=count+1
        split_line=line.strip().split('\t')
        uid=split_line[0]
        length=len(split_line)-2
        if length>maxlen:
            maxlen=length
        user_basket={}
        for i in range(len(split_line)-1):
            split_product=split_line[i+1].strip().split()
            pid=[]
            for j in range(len(split_product)):
                pid.append(split_product[j])
                if split_product[j] not in product_records:
                    product_records.append(split_product[j])
            user_basket[i]=pid
        one_user_record[uid]=user_basket
        user_records.append(one_user_record)
    return user_records, count, maxlen,len(product_records)


def pad_sequences(X,maxlen):
    if len(X) > maxlen:
        v = np.array(X[:maxlen])
    else:
        v = np.zeros(maxlen)
        for i,x in enumerate(X):
            v[i] = x
    v = v.astype('int')
    return v


def deal_with_line(line):
    line = line.strip()
    label,user_item,user2item_neighbors,item2user_neighbors = line.strip().split('|')
    label = int(label)
    user,item = [int(x) for x in user_item.split(',')]
    try:
        item2user_neighbors = [int(x) for x in item2user_neighbors.split(',')]
    except:
        item2user_neighbors = []
    try:
        user2item_neighbors = [int(x) for x in user2item_neighbors.split(',')]
    except:
        user2item_neighbors = []
    user2item_neighbors_vec = pad_sequences(user2item_neighbors,maxlen=MAX_USER_NEIGHBORS_LEN)#user#to_several_hot(user,user2item_neighbors,n_users)
    item2user_neighbors_vec = pad_sequences(item2user_neighbors,maxlen=MAX_ITEM_NEIGHBORS_LEN)#item#to_several_hot(item,item2user_neighbors,n_items)
    return user , item , user2item_neighbors_vec , item2user_neighbors_vec , label


def get_neg_product(list, maxp_idx, num):
    plist=[]
    neglist=[]
    for i in range(len(list)):
        for j in range(len(list[i])):
            if list[i][j] not in plist:
                plist.append(list[i][j])
    i=0
    while i<num:
        nump=random.randint(1, maxp_idx-1)
        if  nump not in plist:
            i=i+1
            neglist.append(nump)
    return neglist


def gen_index_one_vec_onedim(idx):
    #print 'test!=======',idx.shape[0]
    output = np.ones(idx.shape[0])
    for i in range(idx.shape[0]):
            output[i] = i
    #print 'test, output.shape:',output.shape
    return output