from keras.layers import merge
from keras.utils import np_utils
from keras.layers.core import *
from keras.layers.recurrent import LSTM
from keras.models import *
from keras.layers import Flatten,Reshape,MaxPooling1D,RepeatVector
from keras.layers import Input
from keras.models import load_model,Sequential
import keras.layers
from keras import backend as K
import warnings
warnings.filterwarnings("ignore")
import theano as T
#from attention_utils import get_activations, get_data_recurrent
from attention_utils_bai import *
from measures import *
from keras import optimizers

def attention_product(inputs,inputs_c,basket_num, basket_product, embedding_dim,inputs_a,inputs_ca):
    ''' inputs: the input user tensor
    inputs_c: the input category tensor
    basket_num: num of baskets per user
    basket_product: num of products per basket
    embedding_dim : embedding dimension
    inputs_a: attention on inputs
    inputs-c: attention on category

    '''

    inputs = Reshape((basket_num*basket_product * embedding_dim,), name='inputs_p')(inputs)
    inputs_a=Reshape((basket_num*basket_product * embedding_dim,), name='inputs_attention')(inputs_a)
    inputs_c = Reshape((basket_num * basket_product * embedding_dim,), name='inputs_c')(inputs_c)
    inputs_ca = Reshape((basket_num * basket_product * embedding_dim,), name='inputs_cattention')(inputs_ca)
    a_probs = Dense(basket_num*basket_product * embedding_dim, activation='softmax',name='attention_pro')(inputs_a)
    a_probsc = Dense(basket_num * basket_product * embedding_dim, activation='softmax', name='attention_cpro')(inputs_ca)
    output_attention_mul = merge([inputs, a_probs], mode='mul', name='merge_attention')
    output_attention_mul=Reshape((basket_num,basket_product * embedding_dim), name='merge_attention1')(output_attention_mul)
    output_attention_mulc = merge([inputs_c, a_probsc], mode='mul', name='merge_cattention')
    output_attention_mulc = Reshape((basket_num, basket_product * embedding_dim), name='merge_cattention1')(output_attention_mulc)
    output_attention=merge([output_attention_mul, output_attention_mulc], mode='mul', name='merge_all')
    return output_attention


def get_R(X):
    Y, alpha = X[0], X[1]
    ans = K.batch_dot(Y, alpha)
    return ans


def model_attention_product_lstm(max_cindex, max_pindex, num_u, basket_num, basket_product, embedding_dim):
    inputs_item = Input(shape=(basket_num, basket_product))
    inputs_cate=Input(shape=(basket_num,basket_product))
    inputs_user = Input(shape=(1,))
    inputs_p = keras.layers.Embedding(input_dim=max_pindex+1, output_dim=embedding_dim, name='embedding_item', mask_zero=True)(inputs_item)
    inputs_pa=keras.layers.Embedding(input_dim=max_pindex+1, output_dim=embedding_dim, name='embedding_pattention', mask_zero=True)(inputs_item)
    inputs_c = keras.layers.Embedding(input_dim=max_cindex + 1, output_dim=embedding_dim, name='embedding_category', mask_zero=True)(inputs_cate)
    inputs_ca = keras.layers.Embedding(input_dim=max_cindex + 1, output_dim=embedding_dim, name='embedding_cattention',
                                       mask_zero=True)(inputs_cate)
    inputs_u = keras.layers.Embedding(input_dim=num_u+1, output_dim=embedding_dim, name='embedding_user')(inputs_user)
    inputs_p = Lambda(lambda x: x.flatten(2), name='lambdap')(inputs_p)
    inputs_pa = Lambda(lambda x: x.flatten(2), name='lambda_pa')(inputs_pa)
    inputs_c = Lambda(lambda x: x.flatten(2), name='lambdac')(inputs_c)
    inputs_ca = Lambda(lambda x: x.flatten(2), name='lambda_ca')(inputs_ca)

    attention_first = attention_product(inputs_p,inputs_c, basket_num, basket_product, embedding_dim,inputs_pa,inputs_ca)
    print 'test attention product,category: success'
    lstm_units = embedding_dim
    attention_mul = LSTM(lstm_units, return_sequences=True, name='lstm')(attention_first)
    inputs_u = Flatten()(inputs_u)
    inputs_u = RepeatVector(basket_num)(inputs_u)


    merged = merge([attention_mul, inputs_u], mode = 'mul', name='merge')
    print 'test, lstm:success'
    output = Dense(max_pindex, activation='softmax')(merged)
    print 'test, output: success'
    model = Model(input=[inputs_item,inputs_cate,inputs_user], output=output)
    return model


def model_evaluate(model,trainXp, trainXc, users, trainY, topN,flag):
    pred_prob=model.predict([trainXp,trainXc,users])
    pred_prob=pred_prob[:,-1,:]
    if flag==0:
        trainY=trainY[:,1,:]
    if flag==1:
        trainY=trainY
    product_index_vector=gen_index_one_vec(np.ones(trainY.shape))
    f1=0
    ndcg_all=0
    for i in range(pred_prob.shape[0]):
        Z = zip(product_index_vector[i], pred_prob[i])
        Z.sort(key=lambda x: x[1], reverse=True)
        plist, _ = zip(*Z)
        overlap_num = compute_overlap(plist, trainY[i], topN)
        percision = overlap_num * 1.0 / 5
        no_zero = compute_not_zero_new(trainY[i])
        recall = overlap_num * 1.0 / no_zero
        if (percision == 0.0) & (recall == 0.0):
            f1_each = 0.0
        else:
            f1_each = 2 * percision * recall * 1.0 / (percision + recall)
        ndcg = find_ndcg(plist, trainY[i], topN)
        ndcg_all = ndcg_all + ndcg
        f1 = f1 + f1_each
    return f1 / pred_prob.shape[0], ndcg_all / pred_prob.shape[0]


def rank_loss1(y_true, y_pred):
    m=10000
    n=20

    return -m * y_true * K.log(y_pred) - n*(1-y_true) * K.log(1-y_pred)

if __name__ == '__main__':
    Epoch = 25
    batch_size = 200
    embedding_dim = 50
    lrate = 0.001
    decay = 0
    droprate = 0.3
    # jd
    num_u = 9238
    max_pindex = 7973

    basket_num=20
    basket_product=15
    max_cindex=1074
    topN=5
    datap = get_data('data/data_product_shuffle.txt')
    datac=get_data('data/data_category_shuffle.txt')
    trainXp=[]
    trainY=[]
    users=[]
    testXp=[]
    testY=[]
    trainXc=[]
    testXc=[]
    for i in range(1,len(datap)+1):
        users.append(i)
        pad_basketp = padding_basket(datap[i], basket_num)
        pad_basketc=padding_basket(datac[i],basket_num)
        trainXbp = []
        trainXbc=[]
        trainYb = []
        for j in range(len(pad_basketp) - 2):
            pad_product = padding_product(pad_basketp[j], basket_product)
            pad_category=padding_product(pad_basketc[j],basket_product)
            trainXbp.append(pad_product)
            trainXbc.append(pad_category)
            arrayp = gen_index_indicator_vec(pad_basketp[j + 1], max_pindex)
            # print 'test, not zero:', compute_not_zero_new(arrayp)
            trainYb.append(arrayp)
        trainXp.append(trainXbp)
        trainXc.append(trainXbc)
        trainY.append(trainYb)


        testXbp = []
        testXbc=[]
        for k in range(len(pad_basketp) - 2):
            pad_product1 = padding_product(pad_basketp[k + 1], basket_product)
            pad_product1c = padding_product(pad_basketc[k + 1], basket_product)
            testXbp.append(pad_product1)
            testXbc.append(pad_product1c)

        testXp.append(testXbp)
        testXc.append(testXbc)

        arrayt = gen_index_indicator_vec(datap[i][-1], max_pindex)
        testY.append(arrayt)
    #print 'test', users
    users = np.array(users)
    trainXp = np.array(trainXp)
    trainXc=np.array(trainXc)
    trainY = np.array(trainY)
    testXp = np.array(testXp)
    testXc=np.array(testXc)
    testY = np.array(testY)

    # train model
    m_train = model_attention_product_lstm(max_cindex, max_pindex, num_u, basket_num - 2, basket_product, embedding_dim)
    adm= optimizers.Adam(lr=lrate, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    m_train.compile(loss=rank_loss1, optimizer=adm, metrics=['accuracy'])
    print '-------------------------test compile: success-----------------'
    max_f1 = 0
    max_ndcg = 0
    flag_f1_epoch=0
    flag_ndcg_epoch=0
    for epoch in range(Epoch):
        print 'EPOCH=========', epoch
        m_train.fit([trainXp,trainXc, users], trainY, batch_size,verbose=2,epochs=2)
        print '==========================epch:', epoch+1, '\n'
        # print '======evaluation training data============\n'
        # model_f1, ndcg = model_evaluate(m_train, trainXp,trainXc, users, trainY, topN,0)
        # print 'train: f1 value--->', model_f1, 'ndcg--->', ndcg, '\n'
        print '=======evaluation testing data===============\n'
        test_f1, test_ndcg = model_evaluate(m_train, testXp, testXc, users, testY, topN,1)
        if test_f1> max_f1:
            max_f1=test_f1
            flag_f1_epoch=epoch
        if test_ndcg>max_ndcg:
            max_ndcg=test_ndcg
            flag_ndcg_epoch=epoch
        print 'test: f1 value---> ', test_f1, 'ndcg---> ', test_ndcg

    print 'train model over! begin test,max_f1 ', max_f1, 'epch:', flag_f1_epoch,'====>maxndcg', max_ndcg, 'epch:', flag_ndcg_epoch


